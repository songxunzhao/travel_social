<?php
var_dump(posix_getpwuid(posix_geteuid()));
phpinfo();
?>
