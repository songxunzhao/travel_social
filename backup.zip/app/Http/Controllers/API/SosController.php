<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Validator;
use App\Sos;
use App\User;
use DB;
use PushNotification;

class SosController extends Controller
{
    //

	 protected function validator($data) {
        return Validator::make($data, [
            'message'=>'required',
            'lat'=>'numeric|required',
            'lng'=>'numeric|required',
        ]);
        }

        public function store(Request $request){
                $user = $request->user();
                $validator =  $this->validator($request->all());
                $request_data = $request->all();
                $request_data['creator_id'] = $user->id;
                if($validator->fails()) {
                   return response()->json(['code'=>400, 'errors'=> $validator->errors(),
                                    'message'=>'Some fields are missing or wrong']);
                }

                $sos = Sos::create($request_data);
                $sos->save();
		$lat = $request_data['lat'];
		$lng = $request_data['lng'];
		
		$usrs = User::selectRaw('*, p.distance_unit
                 * DEGREES(ACOS(COS(RADIANS(p.latpoint))
                 * COS(RADIANS(users.lat))
                 * COS(RADIANS(p.longpoint) - RADIANS(users.lng))
                 + SIN(RADIANS(p.latpoint))
                 * SIN(RADIANS(users.lat)))) AS distance_in_km')->join(DB::raw("(SELECT  $lat AS latpoint,  $lng AS longpoint,
                        100.0 AS radius,      111.045 AS distance_unit) as p"), function($join) {
                $join->on(DB::raw('1'), '=', DB::raw('1'));
            })->where('id','!=', $user->id)
            ->orderBy('distance_in_km', 'asc')
            ->orderBy('created_at', 'desc')->get();
		//echo "count:".count($usrs);		
            $message = PushNotification::Message('Message Text',array(
    'badge' => +1,
    'sound' => 'default',

    'actionLocKey' => 'respond to the alert!',
    'locKey' => 'Sos Alert!!',
    'locArgs' => array(
        'localized args',
        'localized args',
    ),
    'launchImage' => 'image.jpg',

    'custom' => array('custom data' => array(
        'we' => 'want', 'send to app'
    ))
));
            foreach($usrs as $usr) {
		//echo "username:".$usr->name;
                if($usr->distance_in_km >3)
                        break;
              $deviceToken = $usr->device_token;
		//$deviceToken = 'd24d4776596e1a8d05049103464845a891c72ee8e1fac0e42d621d05e86727a9';
		PushNotification::app('appNameIOS')
                ->to($deviceToken)
                ->send($message);
		}
                return response()->json(['code'=>200, 'data'=> $sos->toArray()]);
        }


}
