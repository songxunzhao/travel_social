<?php
/**
 * Created by PhpStorm.
 * User: songxun
 * Date: 6/7/2016
 * Time: 4:25 PM
 */

?>
<html>
<body>
    <img src="">
    <b>Dear customer</b><br>
    You got invitation from Habbis Dev Team. <br>
    Please download app from this <a href="">link</a> and login.
</body>
</html>