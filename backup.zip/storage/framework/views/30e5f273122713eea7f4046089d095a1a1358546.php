<?php
/**
 * Created by PhpStorm.
 * User: songxun
 * Date: 6/14/2016
 * Time: 9:03 PM
 */
?>
<html>
<body>
<img src="">
<b>Dear customer</b><br>
You requested password reset. Your request code is<br>
<?php echo e($code); ?>

</body>
</html>